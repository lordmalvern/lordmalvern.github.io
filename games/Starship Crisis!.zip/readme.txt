Instructions:
Unzip both the exe and data folder into the same directory to install. 

When prompted for a resolution, choose a widescreen resolution as elements can be clipped out in the default 1024x768.

To play, left click on a tile and drag either horizontally or vertically to scroll through that row or column. When you find a match, release the mouse button. If your board spawns with a match already present, left click on any tile to allow the game to register the match. Match the tiles to the color of the debris to shoot the debris. You can also make matches of other colors to store as "ammo" for future encounters. If you encounter a piece of debris that you can't find an easy match for but you know you have "ammo" for, you can just make any match and the ship will fire the right color for the debris!

To exit, hit alt-F4.  